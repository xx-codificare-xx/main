from tkinter import*
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
from login import Login_Window
import mysql.connector

class Register:
    def __init__(self,root):
        self.root = root
        self.root.title("Register")
        self.root.geometry("1520x800+0+0")

        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_uname=StringVar()
        self.var_pass=StringVar()

        img3 =Image.open(r"C:\Users\snehal\Desktop\python project\img\bg.jpeg")
        img3=img3.resize((1530,800),Image.ANTIALIAS)
        self.photoimg3 = ImageTk.PhotoImage(img3)

        bg_img=Label(self.root,image=self.photoimg3)
        bg_img.place(width=1530,height=800)

        frame=Frame(self.root , bg = "white")
        frame.place(x=520,y=100,width=500,height = 550)

        register_lbl=Label(frame,text ="REGISTER",font=("times new roman",20,"bold"),fg="black")
        register_lbl.grid(row=0,column=1,pady =10)

        studentId_label=Label(frame,text ="First Name",font=("times new roman",12,"bold"))
        studentId_label.grid(row=1,column=0,pady =10)

        studentID_entry=ttk.Entry(frame ,textvariable=self.var_fname ,width =20 , font=("times new roman",13,"bold"))
        studentID_entry.grid(row=1,column=1,pady =10)

        studentName_label=Label(frame,text ="Last Name:",font=("times new roman",12,"bold"))
        studentName_label.grid(row=2,column=0,pady =10)

        studentName_entry=ttk.Entry(frame ,textvariable=self.var_lname, width =20 , font=("times new roman",13,"bold"))
        studentName_entry.grid(row=2,column=1,pady =10)

        user_label=Label(frame,text ="User Name:",font=("times new roman",12,"bold"))
        user_label.grid(row=3,column=0,pady =10)

        user_entry=ttk.Entry(frame ,textvariable=self.var_uname, width =20 , font=("times new roman",13,"bold"))
        user_entry.grid(row=3,column=1,pady =10)

        pass_label=Label(frame,text ="Password :",font=("times new roman",12,"bold"))
        pass_label.grid(row=4,column=0,pady =10)

        pass_entry=ttk.Entry(frame ,textvariable=self.var_pass, width =20 , font=("times new roman",13,"bold"))
        pass_entry.grid(row=4,column=1,pady =10)

        loginbtn = Button(frame,command=self.login,text="Login",font=("times new roman",15,"bold"),bd=3,relief=RIDGE,fg="white",bg="Red",activeforeground="white",activebackground="red")
        loginbtn.place(x=110,y=350,width=120,height=35)

	# register button
        registerbtn = Button(frame,command=self.register_data  ,text="Register",font=("times new roman",10,"bold"),borderwidth=0,fg="white",bg="Black",activeforeground="white",activebackground="black")
        registerbtn.place(x=110,y=300,width=120,height=35)

    def login(self):
        self.new_window = Toplevel(self.root)
        self.app = Login_Window(self.new_window)

    def register_data(self):
        if self.var_fname.get()=="" or self.var_lname.get()=="" or self.var_uname.get()=="" or self.var_fname.get()=="" :
            messagebox.showerror("Error","All Fields are required")
        else:
            #messagebox.showinfo("Success","Welcome")
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="Snehal28&",database="face")
                my_cursor=conn.cursor()
                my_cursor.execute("insert into login values(%s,%s,%s,%s)",(
                                                                                             
                                                                                             self.var_fname.get(),
                                                                                             self.var_lname.get(),
                                                                                             self.var_uname.get(),
                                                                                             self.var_pass.get(),
                                                                                             
                                                                                        ))
                conn.commit()
                conn.close()
                messagebox.showinfo("Success","Student data added successfully!")
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}")
            

        






	
if __name__ == "__main__":
	root = Tk()
	app = Register(root)
	root.mainloop()
