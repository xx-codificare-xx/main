from tkinter import*
from tkinter import ttk
from PIL import Image , ImageTk
from tkinter import messagebox
import mysql.connector
import cv2


class Student:
    def __init__(self , root):
        self.root= root
        self.root.geometry("1530x790+0+0")
        self.root.title(" Face Recognition System")
        img =Image.open(r"C:\Users\snehal\Desktop\python project\img\apsit.jfif")
        img=img.resize((500,130),Image.ANTIALIAS)
        self.photoimg = ImageTk.PhotoImage(img)

        self.var_dep=StringVar()
        self.var_id=StringVar()
        self.var_name=StringVar()
        self.var_course=StringVar()
        self.var_email=StringVar()
        self.var_phone=StringVar()
        
        

        f_lbl=Label(self.root,image=self.photoimg)
        f_lbl.place(x=0,y=0,width=500,height=130)

        img1 =Image.open(r"C:\Users\snehal\Desktop\python project\img\logo.png")
        img1=img1.resize((500,130),Image.ANTIALIAS)
        self.photoimg1 = ImageTk.PhotoImage(img1)

        f_lbl=Label(self.root,image=self.photoimg1)
        f_lbl.place(x=1000,y=0,width=500,height=130)


        img3 =Image.open(r"C:\Users\snehal\Desktop\python project\img\bg.jpeg")
        img3=img3.resize((1530,710),Image.ANTIALIAS)
        self.photoimg3 = ImageTk.PhotoImage(img3)

        bg_img=Label(self.root,image=self.photoimg3)
        bg_img.place(x=0,y=130,width=1530,height=710)

         
        title_lbl = Label(bg_img, text ="Student Details" , font =("times new roman",35,"bold"),bg = "white",fg="black")
        title_lbl.place(x=0,y=0,width=1530,height =45)

        main_frame=Frame(bg_img,bd=2)
        main_frame.place(x=20,y=50,width=1480,height=600)

        Left_frame=LabelFrame(main_frame ,bd =2 , relief = RIDGE , text = "Student Details" , font=("times new roman",12,"bold"))
        Left_frame.place(x=10,y=10,width=760,height=580)

        current_course_frame=LabelFrame(Left_frame ,bd =2 , relief = RIDGE , text = "Current course details" , font=("times new roman",12,"bold"))
        current_course_frame.place(x=10,y=25,width=740,height=150)

        dep_label=Label(current_course_frame,text ="Department",font=("times new roman",12,"bold"))
        dep_label.grid(row=0,column=0)

        dep_combo=ttk.Combobox(current_course_frame ,textvariable=self.var_dep, font=("times new roman",12,"bold"))
        dep_combo["values"]=("Select Department","Computer","IT","Civil","Mechical")
        dep_combo.current(0)
        dep_combo.grid(row=0,column=1)

        course_label=Label(current_course_frame,text ="Course", font=("times new roman",12,"bold"))
        course_label.grid(row=0,column=2)

        course_combo=ttk.Combobox(current_course_frame ,textvariable=self.var_course, font=("times new roman",12,"bold"))
        course_combo["values"]=("Select Course","FE","SE","TE","BE")
        course_combo.current(0)
        course_combo.grid(row=0,column=3)
        

        Class_Student_frame=LabelFrame(Left_frame ,bd =2 , relief = RIDGE , text = "Class student information" , font=("times new roman",12,"bold"))
        Class_Student_frame.place(x=5,y=200,width=720,height=300)

        studentId_label=Label(Class_Student_frame,text ="StudentID:",font=("times new roman",12,"bold"))
        studentId_label.grid(row=0,column=0)

        studentID_entry=ttk.Entry(Class_Student_frame ,textvariable=self.var_id ,width =20 , font=("times new roman",13,"bold"))
        studentID_entry.grid(row=0,column=1)

        studentName_label=Label(Class_Student_frame,text ="Student Name:",font=("times new roman",12,"bold"))
        studentName_label.grid(row=0,column=2)

        studentName_entry=ttk.Entry(Class_Student_frame ,textvariable=self.var_name, width =20 , font=("times new roman",13,"bold"))
        studentName_entry.grid(row=0,column=3)

        email_label=Label(Class_Student_frame,text ="Email",font=("times new roman",12,"bold"))
        email_label.grid(row=1,column=0)

        email_entry=ttk.Entry(Class_Student_frame , width =20 ,textvariable=self.var_email, font=("times new roman",13,"bold"))
        email_entry.grid(row=1,column=1)
        
        phone_label=Label(Class_Student_frame,text ="Phone No.",font=("times new roman",12,"bold"))
        phone_label.grid(row=1,column=2)

        phone_entry=ttk.Entry(Class_Student_frame , textvariable=self.var_phone ,width =20 , font=("times new roman",13,"bold"))
        phone_entry.grid(row=1,column=3)

        self.var_radio1=StringVar()
        radiobtn1=ttk.Radiobutton(Class_Student_frame, text="Take Photo Sample" ,variable=self.var_radio1,value = "Yes")
        radiobtn1.grid(row=5,column=0)

        radiobtn2=ttk.Radiobutton(Class_Student_frame,text="No Photo Sample" ,variable=self.var_radio1, value = "No")
        radiobtn2.grid(row=5,column=1)

        btn_frame=Frame(Class_Student_frame , bd=2,relief=RIDGE,bg="white")
        btn_frame.place(x=0,y=200,width=715,height=35)

        save_btn=Button(btn_frame , text="Save"  ,command=self.add ,width=17 ,font =("times new roman",13,"bold"),bg ="white")
        save_btn.grid(row=0,column=0)

        update_btn=Button(btn_frame,text="Update",command=self.update ,width =17,font=("times new roman",13,"bold"),bg ="white")
        update_btn.grid(row=0,column=1)

        delete_btn=Button(btn_frame,text="Delete",command=self.delete,width =17,font=("times new roman",13,"bold"),bg ="white")
        delete_btn.grid(row=0,column=2)

        reset_btn=Button(btn_frame,text="Reset",command=self.reset , width =17,font=("times new roman",13,"bold"),bg ="white")
        reset_btn.grid(row=0,column=3)

        btn_frame1=Frame(Class_Student_frame , bd=2,relief=RIDGE,bg="white")
        btn_frame1.place(x=0,y=235,width=715,height=35)

        take_photo_btn=Button(btn_frame1,text=" Take photo sample",command=self.generate , width =70,font=("times new roman",13,"bold"),bg ="white")
        take_photo_btn.grid(row=1,column=0)

        
        

        Right_frame=LabelFrame(main_frame ,bd =2 , relief = RIDGE , text = "Student Details" , font=("times new roman",12,"bold"))
        Right_frame.place(x=780,y=10,width=660,height=580)

        

        table_frame=Frame(Right_frame , bd=2,bg="white",relief=RIDGE)
        table_frame.place(x=5,y=10,width=650, height=500)

        scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)

        self.student_table=ttk.Treeview(table_frame,column=("dep","id","name","course","email","phone","photo"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_x.config(command=self.student_table.xview)
        scroll_y.config(command=self.student_table.yview)

        self.student_table.heading("dep",text="Department")
        self.student_table.heading("id",text="Student id")
        self.student_table.heading("name",text="Name")
        self.student_table.heading("course",text="Course")
        self.student_table.heading("email",text="Email")
        self.student_table.heading("phone",text="Phone No.")
        self.student_table.heading("photo",text="Photo Status")
        self.student_table["show"]="headings"

        self.student_table.pack(fill=BOTH,expand=1)
        self.student_table.bind("<ButtonRelease>",self.get_cursor)
        self.fetch()

    def add(self):
            if self.var_dep.get()=="Select Department" or self.var_id.get()=="" or self.var_name.get()=="":
                messagebox.showerror("Error","All Fields are Required")
            else:
                try:
                    conn=mysql.connector.connect(host="localhost",username="root",password="Snehal28&",database="face")
                    my_cursor=conn.cursor()
                    my_cursor.execute("insert into student values(%s,%s,%s,%s,%s,%s,%s)",(
                                                                                             self.var_dep.get(),
                                                                                             self.var_id.get(),
                                                                                             self.var_name.get(),
                                                                                             self.var_course.get(),
                                                                                             self.var_email.get(),
                                                                                             self.var_phone.get(),
                                                                                             self.var_radio1.get()
                                                                                        ))
                    conn.commit()
                    self.fetch()
                    conn.close()
                    messagebox.showinfo("Success","Student data added successfully!")
                except Exception as es:
                    messagebox.showerror("Error",f"Due To :{str(es)}")

    def fetch(self):
        conn=mysql.connector.connect(host="localhost",username="root",password="Snehal28&",database="face")
        my_cursor=conn.cursor()
        my_cursor.execute("select  * from student")
        data=my_cursor.fetchall()

        if len(data)!=0:
            self.student_table.delete(*self.student_table.get_children())
            for i in data:
                self.student_table.insert("" ,END,values=i)
            conn.commit()
        conn.close()


    def get_cursor(self,event=""):
        cursor_focus=self.student_table.focus()
        content=self.student_table.item(cursor_focus)
        data=content["values"]

        self.var_dep.set(data[0]),
        self.var_id.set(data[1]),
        self.var_name.set(data[2]),
        self.var_course.set(data[3]),
        self.var_email.set(data[4]),
        self.var_phone.set(data[5]),
        self.var_radio1.set(data[6])
        



    def update(self):
        if self.var_dep.get()=="Select Department" or self.var_id.get()=="" or self.var_name.get()=="":
                messagebox.showerror("Error","All Fields are Required")
        else:
            try:
                Update=messagebox.askyesno("Update","do you waant to update this student details")
                if Update>0:
                    conn=mysql.connector.connect(host="localhost",username="root",password="Snehal28&",database="face")
                    my_cursor=conn.cursor()
                    my_cursor.execute(("update student set dep=%s , name=%s, course=%s,email=%s ,phone=%s , photo=%s where id=%s "),(
                                                                                                         self.var_dep.get(),
                                                                                                         self.var_name.get(),
                                                                                                         self.var_course.get(),
                                                                                                         self.var_email.get(),
                                                                                                         self.var_phone.get(),
                                                                                                         self.var_radio1.get(),
                                                                                                         self.var_id.get()
                                                                                                      ))
                else:
                    if not Update:
                        return
                messagebox.showinfo("Success","Student data Updated successfully!")
                conn.commit()
                self.fetch()
                conn.close()
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}")
                                

    def delete(self):
        if self.var_id.get()=="":
            messagebox.showerror("Error","Student id must be required")
        else:
            try:
                delete=messagebox.askyesno("Delete","do you want to delete this student details")
                if delete>0:
                    conn=mysql.connector.connect(host="localhost",username="root",password="Snehal28&",database="face")
                    my_cursor=conn.cursor()
                    my_cursor.execute(("delete from student where id=%s "),(self.var_id.get(),))
                else:
                    if not delete:
                        return
                messagebox.showinfo("Success","Student data deleted successfully!")
                conn.commit()
                self.fetch()
                conn.close()
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}")


    def reset(self):
        self.var_dep.set("Select Department"),
        self.var_id.set(""),
        self.var_name.set(""),
        self.var_course.set("Select Course"),
        self.var_email.set(""),
        self.var_phone.set(""),
        self.var_radio1.set("")


    def generate(self):
        if self.var_dep.get()=="Select Department" or self.var_id.get()=="" or self.var_name.get()=="":
            messagebox.showerror("Error","All Fields are Required")
        else:
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="Snehal28&",database="face")
                my_cursor=conn.cursor()
                my_cursor.execute("select * from student")
                result=my_cursor.fetchall()
                id=0
                for x in result:
                    id+=1
                my_cursor.execute(("update student set dep=%s , name=%s, course=%s,email=%s ,phone=%s , photo=%s where id=%s "),(
                                                                                                         self.var_dep.get(),
                                                                                                         self.var_name.get(),
                                                                                                         self.var_course.get(),
                                                                                                         self.var_email.get(),
                                                                                                         self.var_phone.get(),
                                                                                                         self.var_radio1.get(),
                                                                                                         self.var_id.get()==id+1
                                                                                                         ))
                conn.commit()
                self.fetch()
                self.reset()
                conn.close()

                face_classifier=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

                def face_cropped(img):
                    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
                    faces=face_classifier.detectMultiScale(gray,1.3,5)
                    for(x,y,w,h) in faces:
                        face_cropped=img[y:y+h,x:x+w]
                        return face_cropped
                cap=cv2.VideoCapture(0)
                img_id=0
                while True:
                    ret,my_frame=cap.read()
                    if face_cropped(my_frame) is not None:
                        img_id+=1
                    face=cv2.resize(face_cropped(my_frame),(300,300))
                    face=cv2.cvtColor(face,cv2.COLOR_BGR2GRAY)
                    filename="data/user."+str(id)+"."+str(img_id)+".jpg"
                    cv2.imwrite(filename,face)
                    cv2.putText(face,str(img_id),(50,50),cv2.FONT_HERSHEY_COMPLEX,2,(0,255,0),2)
                    cv2.imshow("cropped face" , face)
                    if cv2.waitKey(1)==13 or int(img_id)==25:
                        break
                cap.release()
                cv2.destroyAllWindows()
                messagebox.showinfo("Result","Generating data set complete!!!")
                    
            except Exception as es:
                messagebox.showerror("Error",f"Due To :{str(es)}")
                                

                 
                
                         
                    
                
        
    
                    
        
        
if __name__ == "__main__":
    root = Tk()
    obj= Student(root)
    root.mainloop()
